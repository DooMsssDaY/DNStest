<?php
/**
 * Класс с настройками
 */
Class Config
	{
		// настройки подключения к БД
		const DB_HOST = 'localhost';
		const DB_USER = 'root';
		const DB_PASSWORD = '';
		const DB_NAME = 'DNStest';
		const DB_TAB_PREFIX = 'tree_';
	}
?>