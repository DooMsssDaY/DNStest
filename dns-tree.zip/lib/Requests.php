<?php
    require_once"Controller.php";
/**
 * Обработчики ajax-запросов
 */

// получение содержимого директории по id
if(isset($_REQUEST['get']))
{
	    $req = $_REQUEST['get'];

	    $control = new Controller();
	    $resp = $control->getFiles($req);
	    unset($_REQUEST['get']);

	    echo json_encode($resp);
}

//изменение родительского каталога элемента
if(isset($_REQUEST['set_p_id']) && isset($_REQUEST['id']))
{
    	$p_id = $_REQUEST['set_p_id'];
    	$id = $_REQUEST['id'];

    	$control = new Controller();
    	$control->setParent($p_id, $id);

    	unset($_REQUEST['set_p_id']);
    	unset($_REQUEST['id']);
}

?>