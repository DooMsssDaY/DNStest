﻿<!DOCTYPE html>
<head>
    <meta charset="utf-8" />
    <title>Ajax дерево файлов</title>
    <script src="js/jquery-1.10.2.min.js" type="text/javascript"></script>
    <script src="js/main.js" type="text/javascript"></script>

    <link type="text/css" href="css/index.css" rel="stylesheet"/>
</head>

<body>
    <div class="page-wrapper">
        <h1>Ajax-дерево папок</h1>
        <div id="content">        
                <ul class="tree" nodrop='true' ondragenter="return dragEnter(event)" ondrop="return dragDrop(event)" ondragover="return dragOver(event)">
                    <div id="fol_1_div">  
                        <li id="fol_1" class="folder">Files</li>
                            <ul nodrop='true' id='ul_1' class="hidden"></ul>
                    </div>
                </ul> 
        </div>
        <div class="page-buffer">
    </div>
    </div>
        <div class="page-footer">
            Тестовое задание для DNS. 2015г.
            <span class='right'>Турушев Николай(Tur.Nik.8@mail.ru)</span>
        </div>

</body>
</html>
